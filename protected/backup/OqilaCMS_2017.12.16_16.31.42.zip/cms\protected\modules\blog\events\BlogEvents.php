<?php

/**
 * Class BlogEvents
 */
class BlogEvents
{
    /**
     *
     */
    const POST_PUBLISH = 'blog.post.publish';

    /**
     *
     */
    const BLOG_JOIN = 'blog.blog.join';

    /**
     *
     */
    const BLOG_LEAVE = 'blog.blog.leave';
}
