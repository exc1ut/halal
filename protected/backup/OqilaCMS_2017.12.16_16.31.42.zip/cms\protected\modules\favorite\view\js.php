<script type="text/javascript">
    var yupeStoreAddFavoriteUrl = '<?= Yii::app()->createAbsoluteUrl('/favorite/default/add'); ?>';
    var yupeStoreRemoveFavoriteUrl = '<?= Yii::app()->createAbsoluteUrl('/favorite/default/remove'); ?>'
</script>