<?php
return [
    'Favorite' => 'Избранные товары',
    'Store' => 'Магазин',
    'Favorite products module' => 'Модуль для добавления товаров в избранное',
    'Success added!' => 'Успешно добавлено!',
    'Error =(' => 'Произошла ошибка =(',
    'Success removed!' => 'Успешно удалено!',
    'Remove error =(' => 'При удалении произошла ошибка =('
];