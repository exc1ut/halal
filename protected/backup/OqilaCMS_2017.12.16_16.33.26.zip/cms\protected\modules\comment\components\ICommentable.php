<?php

interface ICommentable
{
    public function getTitle();

    public function getLink();
}
