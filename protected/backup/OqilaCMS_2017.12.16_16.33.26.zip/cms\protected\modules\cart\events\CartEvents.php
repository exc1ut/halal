<?php
class CartEvents
{
    const CART_ADD_ITEM = 'cart.item.add';
    const CART_REMOVE_ITEM = 'cart.item.remove';
    const CART_CLEAR = 'cart.clear';
    const CART_UPDATE = 'cart.update';
}