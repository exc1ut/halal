<?php

/**
 * Class FeedbackEvents
 */
class FeedbackEvents
{
    /**
     *
     */
    const SEND_SUCCESS = 'feedback.send.success';
}